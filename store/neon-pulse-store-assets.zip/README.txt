Neon Pulse - Google Play paketi
================================
1-icon/              512x512 uygulama ikonu (Play Console > Ana mağaza girişi > Uygulama simgesi).
                     android-adaptive/ klasörü AAB içine zaten gömülüdür; bilgi amaçlıdır.
2-feature-graphic/   1024x500 öne çıkan grafik.
3-screenshots/       1920x1080 yatay telefon ekran görüntüleri (Play en az 2, en fazla 8 kabul eder).
4-listing/           Başlık, kısa/tam açıklama (EN, TR) ve Play Console form önerileri.
5-privacy/           Gizlilik politikası metni. Yayında: https://geometrilite.vercel.app/privacy
